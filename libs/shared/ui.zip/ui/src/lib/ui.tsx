export function Ui() {
  return (
    <div className="">
      <h1>Welcome to Ui!</h1>
    </div>
  );
}

export default Ui;
